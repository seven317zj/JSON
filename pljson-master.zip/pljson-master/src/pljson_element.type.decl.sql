create or replace type  pljson_element force as object
(
  obj_type number
)
not final;
/
sho err